#include <sdsl/wavelet_trees.hpp>
#include <iostream>
#include <utility>
#include <string>

using namespace std;
using namespace sdsl;

template<class value_type, class size_type>
ostream& operator<<(ostream& os, const std::pair<value_type, size_type>& p)
{
    return os << "(" << p.first << "," << p.second << ")";
}

int main()
{
    wt_int<rrr_vector<63>> wt;
    #int_vector<> table = {6, 3000,0, 6 ,4, 7, 3, 18, 6, 3};
    int_vector<> table;
    table.resize(10)
    cout<<"width:" <<(int)table.width()<<endl;   
   
    construct_im(wt, table);
    cout<<wt.size()<<" "<<wt.sigma<<" "<<wt[1]<<endl;
   

    vector<uint64_t> values(9),r1(9),r2(9);
   

    uint64_t hitnum;

    wt.interval_symbols(0,5,hitnum,values,r1,r2);


    cout<<hitnum<<endl;


    for(unsigned int i = 0;i<values.size();i++)
        cout<<values[i]<<endl;
    auto res = wt.range_search_2d(1, 5, 4, 18);
    for (auto point : res.second)
        cout << point << " ";
    cout << endl;
}

#include <sdsl/wavelet_trees.hpp>
#include <iostream>

using namespace sdsl;
using namespace std;
int main(int argc,char* argv[]){
    wt_int<rrr_vector<63>>wt;
    load_from_file(wt,argv[1]);

    cout<<wt.size()<<" "<<wt.sigma<<endl;

    uint64_t idx;
    while(cin>>idx){
        if(idx == 0)break;
        cout<<wt[idx]<<endl;


    }
    return 0;



}

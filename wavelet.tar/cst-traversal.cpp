#include <sdsl/suffix_trees.hpp>
#include <iostream>
#include <string>

using namespace sdsl;
using namespace std;

int main(int argc, char* argv[])
{
    if (argc < 3) {
        cout << "Usage: " << argv[0] << " file " << "int [max_depth]" << endl;
        return 1;
    }
    cst_sct3<> cst;
    //construct(cst, argv[1], 1);
    load_from_file(cst,argv[1]);
    uint64_t max_depth = stoull(argv[2]);

    uint64_t maxd = 0;
    // use the DFS iterator to traverse `cst
    
    for (auto it=cst.begin(); it!=cst.end(); ++it) {
        
        if (it.visit() == 1) {  // node visited the first time
            auto v = *it;       // get the node by dereferencing the iterator
            if (cst.depth(v)<3) {   // if depth node is <= max_depth
                // process node, e.g. output it in format d-[lb, rb]
                if (cst.depth(v) > maxd) maxd = cst.depth(v);
                //cout<<cst.depth(v)<<" "<<cst.lb(v)<<" "<<cst.rb(v)<<" leaf num: "<<cst.size(v)<<" "<<cst.lb(cst.select_leaf((int)cst.size(v)/2+1))<<" "<<cst.rb(cst.select_leaf((int)cst.size(v)))<<endl;
                cout<<cst.depth(v)<<"-["<<cst.lb(v)<< ","<<cst.rb(v)<<"]"<<endl;
                
            } else { // skip the subtree otherwise
                //it.skip_subtree();
            }
        }
        
    }
    cout<<maxd<<endl;
}

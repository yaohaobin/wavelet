#include <sdsl/suffix_trees.hpp>
#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <set>

using namespace sdsl;
using namespace std;
void set_insert(set<unsigned>& s1,set<unsigned>::iterator it1,set<unsigned>::iterator it2){
    for(set<unsigned>::iterator itr = it1;itr!=it2;itr++)
        s1.insert(*itr);

}
int main(int argc, char* argv[])
{
    if (argc < 2) {
        cout << "Usage: " << argv[0] << " file " << endl;
        return 1;
    }
    cst_sct3<> cst;
    //construct(cst, argv[1], 1);
    load_from_file(cst,argv[1]);

    string seqlenfile(argv[1]);
    seqlenfile = seqlenfile.replace(seqlenfile.find(".cst"),4,".len");
    cout<<"length file: "<<seqlenfile<<endl;
    ifstream seqinfo(seqlenfile.c_str());
    string len;
    
    //uint64_t max_num = stoull(argv[2]);

    uint64_t maxd = 0;
    // use the DFS iterator to traverse `cst`
    int_vector<>common(cst.csa.size(),0);
    int_vector<>cover(cst.csa.size(),0);    
    int_vector<>nexthit(cst.csa.size(),cst.csa.size()-1);
    int sharenum = 0;
    float mean = 0;    
    int idx = 0;
    int seqnum = 0;

    string gi;
    while(seqinfo>>gi>>len){
        uint64_t seqlen = stoull(len.c_str())+1;
        cout<<seqlen<<endl;
        seqnum++;
        for(int i=idx;i<idx+seqlen;i++)
            common[i] = seqnum;
        idx += seqlen;
    }
    seqinfo.close();
        
    string commonstr(argv[1]);
    commonstr = commonstr+".common";

    ofstream commonout(commonstr.c_str());
      
    
    vector<set<unsigned> > nodeset(cst.nodes());
    //vector<set<unsigned>::iterator > nodebegin(cst.nodes());
    //vector<set<unsigned>::iterator > nodeend(cst.nodes());
    vector<unsigned >setsize(cst.nodes(),0);
    int_vector<1>skipnode(cst.nodes(),0);
    //int leafnum = cst.size(cst.root());
    auto root = cst.root();
    common[cst.csa.size()-1] = seqnum;    
    cout<<common[cst.csa.size()-1]<<" "<<cst.csa[0]<<" "<<cst.csa[cst.csa.size()-1]<<" "<<cst.nodes()<<endl;
    unsigned max = 0;   
    uint64_t num = 0;
    unsigned maxrb= 0;
    for (auto it=cst.begin_bottom_up(); it!=cst.end_bottom_up(); ++it) {
        /*
        if (it.visit() == 1) {  // node visited the first time
            auto v = *it;
                   // get the node by dereferencing the iterator
            if (cst.depth(v)<3) {   // if depth node is <= max_depth
                // process node, e.g. output it in format d-[lb, rb]
                if (cst.depth(v) > maxd) maxd = cst.depth(v);
                //cout<<cst.depth(v)<<" "<<cst.lb(v)<<" "<<cst.rb(v)<<" leaf num: "<<cst.size(v)<<" "<<cst.lb(cst.select_leaf((int)cst.size(v)/2+1))<<" "<<cst.rb(cst.select_leaf((int)cst.size(v)))<<endl;
                cout<<cst.depth(v)<<"-["<<cst.lb(v)<< ","<<cst.rb(v)<<"]"<<endl;                
                
            }
            
        }*/
        //if(num>max_num)break;
        auto v = *it;
        if (cst.id(v) == cst.id(root))continue;
        //cout<<cst.depth(v)<<" "<<cst.id(v)<<" "<<cst.rb(v)<<endl;
        

        unsigned parentid = cst.id(cst.parent(v));
        unsigned thisid = cst.id(v);  
        //continue;
        
        
        if (skipnode[thisid] == 1){
            skipnode[parentid] = 1;
            continue;
        }
        int endpos = cst.csa[ cst.lb(v) ] + cst.depth(v) - 1;
        if (cst.depth(v)<=cover[ endpos ]){
            skipnode[parentid] = 1;
            continue;
        }
        //cover[endpos] = cst.depth(v);
        //cout<<cst.depth(v)<<" "<<thisid<<" "<<cst.rb(v)<<" "<<parentid<<endl;
        if (cst.is_leaf(v)){
            
            //unsigned parentid = cst.id(cst.parent(v));
            //unsigned thisid = cst.id(v);
            if (setsize[parentid] == 0){
                set<unsigned> coverseq;
                coverseq.insert(common[cst.csa[cst.rb(v)]]);
                
                //cout<<"leaf "<<cst.csa[cst.rb(v)]<<" "<<common[cst.csa[cst.rb(v)]]<<endl;

                nodeset[parentid] = coverseq;
                //nodebegin[parentid] = coverseq.begin();
                //nodeend[parentid] = coverseq.end();
                setsize[parentid] = 1;                
            } 
            else if(setsize[parentid]<seqnum){
               //set<unsigned>coverseq;
               //coverseq.insert(nodebegin[parentid],nodeend[parentid]);
               //coverseq.insert(nodebegin[thisid],nodeend[thisid]);
               //set_insert(coverseq,nodebegin[parentid],nodeend[parentid]);
               
               nodeset[parentid].insert(common[cst.csa[cst.rb(v)]]);
               
               setsize[parentid] = nodeset[parentid].size();
               //nodebegin[parentid] = coverseq.begin();
               //nodeend[parentid] = coverseq.end();
               
               //if (parentid == cst.id(root))
                   //cout<<"leaf "<<cst.csa[cst.rb(v)]<<" "<<common[cst.csa[cst.rb(v)]]<<endl;               
            }
      
        }
        else{
            if(setsize[thisid] == seqnum){
               cover[endpos] = cst.depth(v);
               max++;
               skipnode[parentid] = 1;
               if(cst.depth(v) > maxrb)maxrb = cst.depth(v);

               mean = (mean*sharenum+cst.depth(v)  )/(sharenum+1);
               sharenum++;
               commonout<<cst.depth(v)<<" "<<cst.lb(v)<<" "<<cst.rb(v)<<" "<<cst.csa[cst.lb(v)]<<" "<<cst.csa[cst.rb(v)]<<endl;
            }
            if(setsize[parentid] == 0){
               set<unsigned> coverseq;
               coverseq.insert(nodeset[thisid].begin(),nodeset[thisid].end());
               nodeset[parentid] = coverseq;
               setsize[parentid] = coverseq.size();
               nodeset[thisid].clear();
            }
            else if(setsize[parentid]<seqnum){
               if (nodeset[thisid].size() == seqnum)
                   nodeset[parentid] = nodeset[thisid];               
               else{
                   nodeset[parentid].insert(nodeset[thisid].begin(),nodeset[thisid].end());
                   nodeset[thisid].clear();
               }
               setsize[parentid] = nodeset[parentid].size();  
            
            }
            //set<unsigned>::iterator it1 = nodebegin[cst.id(v)].begin();
            //set<unsigned>::iterator it2 = nodecover[cst.id(v)].end();
            //nodecover[cst.id(cst.parent(v))].insert(it1,it2);
          
        }
       
        //if (max<setsize[parentid]) max = setsize[parentid];
        //cout<<"parent size: "<<setsize[parentid]<<endl;
        num++;
    }

    commonout.close();
    cout<<"root size: "<<setsize[cst.id(cst.root())]<<" "<<maxrb<<" "<<mean<<" "<<sharenum<<endl;
}

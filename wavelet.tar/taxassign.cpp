#include<iostream>
#include<fstream>
#include<vector>
#include<map>
#include<set>
#include<stack>
#include<algorithm>
#include<sstream>
#include<stdlib.h>
#include<string>
#include<omp.h>

#include <sdsl/suffix_trees.hpp>
#define k 15
#define exk 9
using namespace std;
using namespace sdsl;



bool comp(pair<unsigned int,unsigned int>& p1,pair<unsigned int,unsigned int>& p2){

   return p1.second > p2.second;

}


unsigned int seqnum;


template<class t_csa, class t_pat=typename t_csa::string_type>
uint64_t search(t_csa& csa,  t_pat pat,t_pat ext,map<unsigned int,unsigned int>&result,map<unsigned int,unsigned int >& hitnum,vector<uint16_t>&table){
   uint64_t lb=0, rb=csa.size()-1;
   uint64_t last_lb = lb, last_rb = rb;  
   map<unsigned int,unsigned int> kmerresult; 
   if (backward_search(csa, lb, rb, pat.begin(), pat.end(), lb, rb)>0){
        unsigned int len = 1;
        for (auto it=ext.end(); it != ext.begin() and lb <= rb;) {
            --it;
            len++;
            if (backward_search(csa, lb, rb, (typename t_csa::char_type)*it, last_lb, last_rb) > 0) {
                lb = last_lb;
                rb = last_rb;
            }
            else 
               break;
        }
        for(uint64_t i = lb;i<=rb;i++){
            kmerresult[table[i]]=1;
            
            
        }

        for(map<unsigned int,unsigned int>::iterator itr=kmerresult.begin();itr!=kmerresult.end();itr++){
            result[itr->first] += len;
            hitnum[itr->first] ++;
        }
        return len;
   }
   else
       return 0;

}



void genquery(string& querytext,string& query){
   
    //unsigned long insertpos = seqtext.size();
  


    uint8_t text=0,revcomp=0,temp=0;
    int idx = 0;

    
    for(size_t i=0;i<query.length();i++){



        switch(query[i]){
            //case 'a': text[i] = 1;break;
            case 'A': temp = 0;break;
            case 'C': temp = 1;break;
            case 'T': temp = 2;break;
            case 'G': temp = 3;break;
            default: temp = 4;

        }

                if(temp<4){
                        text= (text<<2) | temp;
                        revcomp = revcomp | temp<<(2*idx);

                        idx++;
                        if(idx>2){
                                querytext+= text+1;
                                //querytext+= text<revcomp?text:revcomp + 1;
                                
                                text = 0;
                                revcomp = 0;
                                idx = 0;
                        }
                }



    }

        if(idx !=0){
                querytext+= text + 1;
            
        }
   

}

template<class t_csa>
double queryseq(string& seq,t_csa& csa,vector<uint16_t>&table,map<unsigned int,unsigned int>&result,map<unsigned int,unsigned int>&hitnum){
  
  map<string,string>kmers;
  for(unsigned int i=0;i<seq.length()-k-exk;i++){
    
    string querytext="",queryext="";
    string ext = seq.substr(i,exk);
    string kmer = seq.substr(i+exk,k);
    genquery(querytext,kmer);
    genquery(queryext,ext);
    kmers[querytext] = queryext;
 
  }
  //cout<<kmers.size()<<endl;
  double mean = 0;
  int num = 0;
 
  
  map<unsigned int,unsigned int> temphitnum;
  for(map<string,string>::iterator itr = kmers.begin();itr!=kmers.end();itr++){
    //cout<<itr->first.length()<<" "<<itr->second.length()<<endl;
    uint64_t hits= search(csa,itr->first,itr->second,result,temphitnum,table);
    if(hits>0){
        mean = (mean*num+hits)/(num+1);
        num++;
    }
  }
  //cout<<mean<<endl;;

  /*
  for(map<unsigned int,unsigned int>::iterator itr = result.begin();itr!=result.end();itr++){
       if(itr->second>5)
           cout<<itr->first<<" "<<itr->second<<endl;
 
  }
  */

  
     
     vector<pair<unsigned int,unsigned int> >resultlist;
     for(map<unsigned int,unsigned int>::iterator itr = result.begin();itr!=result.end();itr++)
         if(itr->second >= 5)
             resultlist.push_back(make_pair(itr->first,itr->second));
            
             
     sort(resultlist.begin(),resultlist.end(),comp);
     result.clear();
     
     for(unsigned int i=0;i<10 && i<resultlist.size();i++){
         result[resultlist[i].first] = resultlist[i].second;
         hitnum[resultlist[i].first] = temphitnum[resultlist[i].first];
     }
         
     

  

  return mean;


  
}

template<class t_csa>
void queryseq(string& seq,t_csa& csa,vector<uint16_t>&table,double& meanhit,unsigned int & besthit, unsigned int& bestscore){

  map<string,string>kmers;
  for(unsigned int i=0;i<seq.length()-k-exk;i++){

    string querytext="",queryext="";
    string ext = seq.substr(i,exk);
    string kmer = seq.substr(i+exk,k);
    genquery(querytext,kmer);
    genquery(queryext,ext);
    kmers[querytext] = queryext;

  }
  //cout<<kmers.size()<<endl;
  double mean = 0;
  int num = 0;

  map<unsigned int,unsigned int> result;
  for(map<string,string>::iterator itr = kmers.begin();itr!=kmers.end();itr++){
    //cout<<itr->first.length()<<" "<<itr->second.length()<<endl;
    
    uint64_t hits= search(csa,itr->first,itr->second,result,table);
    
    if(hits>0){
        mean = (mean*num+hits)/(num+1);
        num++;
    }
  }
  //cout<<mean<<endl;;

  /*
  for(map<unsigned int,unsigned int>::iterator itr = result.begin();itr!=result.end();itr++){
       if(itr->second>5)
           cout<<itr->first<<" "<<itr->second<<endl;

  }
  */
 meanhit = mean;

 for(map<unsigned int,unsigned int>::iterator itr = result.begin();itr!=result.end();itr++){
     if (itr->second > bestscore){
         besthit=itr->first;
         bestscore = itr->second;
     }
 }
  
 return ;
 

     vector<pair<unsigned int,unsigned int> >resultlist;
     for(map<unsigned int,unsigned int>::iterator itr = result.begin();itr!=result.end();itr++)
         if(itr->second >= 10)
             resultlist.push_back(make_pair(itr->first,itr->second));
     sort(resultlist.begin(),resultlist.end(),comp);
     result.clear();
     for(unsigned int i=0;i<10 && i<resultlist.size();i++)
         result[resultlist[i].first] = resultlist[i].second;





 



}


void gentable(vector<uint16_t>& table,string csafile,string lenfile){
  csa_bitcompressed<>csa;
  load_from_file(csa,csafile.c_str());
  vector<uint16_t> belong(csa.size(),0);
  
  
  ifstream leninfo(lenfile.c_str());
  string gi;
  uint64_t len;
  int num = 0;
  uint64_t idx = 0;
  while(leninfo>>gi>>len){
     
     for(unsigned int i=0;i<len;i++){
         belong[idx] = num;
         idx++;
     }
     num++;
  }
  cout<<"csasize"<<" "<<csa.size()<<" "<<belong.size()<<endl;
  cout<<num<<" "<<idx<<endl;
  set<unsigned int>geset;
  table[0] = 0;
  for(unsigned long int i = 1;i<csa.size();i++){
     
     unsigned int value = belong[csa[i]];
     geset.insert(value);
     table[i] = value;
  }
  cout<<"gesize: "<<geset.size()<<endl;
  

}

void readtable(vector<uint16_t>& table,string tablefile){
  ifstream tablein(tablefile.c_str());
  int max = 0;
  for(unsigned long i=0;i<table.size();i++){
      tablein>>table[i];
      if(table[i]>max)max = table[i];
  }
  cout<<"max: "<<max<<endl;
  tablein.close();

}


/*
int main(int argc,char* argv[]){
  if(argc < 2)return 0;
  csa_wt<>csa;
  load_from_file(csa,argv[1]);
  cout<<"csa size "<<csa.size()<<endl;


  vector<unsigned int> table(csa.size(),0);

  gentable(table,argv[3],argv[4]);

  
  
  ifstream samplelist(argv[2]);

  string samplename;
  while(samplelist>>samplename){
     classify(csa,table,samplename);

  }
  samplelist.close();
  return 0;
}

*/


void classify(csa_wt<>&csa,vector<uint16_t>& table,string samplename){

  cout<<"sample: "<<samplename<<endl;
  ifstream seqfile(samplename.c_str() );
  string line;
  vector<string>seqs;
  while(!seqfile.eof() ){
    
    getline(seqfile,line);
    if(line.length() == 0)break;
    getline(seqfile,line);
    string pair = line;
    pair+=(char)66;
    getline(seqfile,line);
    getline(seqfile,line);
    pair+=line;    
    seqs.push_back(pair);

    //cout<<line.length()<<endl;
    //cout<<queryseq(line,csa)<<endl;
  }
  cout<<"seq num: "<<seqs.size()<<endl;
  
  seqnum = seqs.size();
 
  //vector<unsigned int> table(csa.size(),0);
  
  //gentable(table,argv[3],argv[4]);
  vector<map<unsigned int,unsigned int> > sampleresult(seqs.size()),samplehitnum(seqs.size());
  vector<double>meanhit(seqs.size(),0);
  //vector<unsigned int>besthit(seqs.size(),0);
  //vector<unsigned int>bestscore(seqs.size(),0);
  
  /*  
  cout<<"gen wt: "<<endl;

  wt_int<rrr_vector<63>> wt;
  construct_im(wt,table);

  cout<<wt.size()<<" "<<wt.sigma<<" "<<wt[0]<<" "<<table[12346]<<" "<<wt[12346]<<endl;
  int end;
  table.resize(0);
  cin>>end;
  store_to_file(wt,"whole.tw1");
  return 0;
  */


  #pragma omp parallel for
  
      
      for(unsigned int i=0;i<seqs.size();i++){
           meanhit[i] = queryseq(seqs[i],csa,table,sampleresult[i],samplehitnum[i]);
           //cout<<result[i]<<endl;
     }
           
           
 
  //cout<<"classify: "<<classify<<endl; 


  cout<<"output"<<endl;
  string resultfile = samplename + ".sp15";
  ofstream fout(resultfile.c_str());
  
  for(unsigned int i=0;i<seqs.size();i++){
     fout<<seqs[i].length()<<" "<<sampleresult[i].size()<<" "<<meanhit[i]<<" ";
     
     for(map<unsigned int,unsigned int>::iterator itr = sampleresult[i].begin();itr!=sampleresult[i].end();itr++)
         fout<<itr->first<<" "<<itr->second<<" "<<samplehitnum[i][itr->first]<<" ";
    
     fout<<endl;

  }
  /*

  for(unsigned int i=0;i<seqs.size();i++){
      fout<<seqs[i].length()<<" "<<meanhit[i]<<" "<<besthit[i]<<" "<<bestscore[i]<<endl;
  }
  
  */
  fout.close();
  /*
  int_vector<16>common(csa.size(),0);
  cout<<size_in_mega_bytes(common);
  for(unsigned long int i = 0;i<csa.size();i++){
     common[i] = (uint16_t)csa[i];
  } 
  */      
  seqfile.close();
  
  
}
  
int main(int argc,char* argv[]){
  if(argc < 2)return 0;
  csa_wt<>csa;
  load_from_file(csa,argv[1]);
  cout<<"csa size "<<csa.size()<<endl;


  vector<uint16_t> table(csa.size(),0);

  //gentable(table,argv[3],argv[4]);
  readtable(table,argv[3]);
  cout<<"load finish"<<endl;
  /*
  ofstream tableout(argv[5]);
  cout<<"output"<<endl;
  for(unsigned long i=0;i<table.size();i++)
      tableout<<table[i]<<" ";
  tableout<<endl;
  tableout.close();
  */
  

  ifstream samplelist(argv[2]);

  string samplename;
  while(samplelist>>samplename){
     classify(csa,table,samplename);

  }
  samplelist.close();
  return 0;
}
  

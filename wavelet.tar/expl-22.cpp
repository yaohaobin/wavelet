#include <sdsl/suffix_trees.hpp>
#include <iostream>
#include <vector>
#include <initializer_list>
using namespace sdsl;
using namespace std;

int main()
{
    //cst_sct3<csa_wt<wt_hutu<rrr_vector<>>>> cst;
    cst_sct3<csa_bitcompressed<>>cst;
    
    int_vector<> data(100000, 0,8);
    int num =0;
    for (size_t i=0; i < 100000; ++i){
        data[i] = 1+rand()%7;
        if(data[i] == 1)num ++;
        
    }
    cout<<data[9999]<<endl;
    data.resize(10000);
    cout<<data[9999]<<endl; 
    construct_im(cst, data);

    lcp_wt<>lcp;
    construct_im(lcp,data);
    cout << "cst.csa.sigma: " << cst.csa.sigma << endl;
    cout<<locate(cst.csa,"\1").size()<<endl;
    cout<<num<<endl;
    return 0;
    for(size_t i=2;i<cst.lcp.size()-1;i++)
        if(lcp[i+1] != cst.lcp[i])cout<<i<<" "<<lcp[i+1]<<" "<<cst.lcp[i]<<endl;
    cout<<lcp.size()<<" "<<cst.lcp.size()<<" "<<lcp[35]<<" "<<cst.lcp[34]<<endl;
    for (size_t k=0; k<3; ++k)
        cout << "H" << k << "(data) : " <<  get<0>(Hk(cst, k)) << endl;
}
